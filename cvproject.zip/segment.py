class segment():
    def process(self):
        pass