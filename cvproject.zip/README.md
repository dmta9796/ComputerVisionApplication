# Computer vision project
The project is mainly to see the limitations
of various tracking algorithms. 
## dependancies
The project is dependant on having Anaconda which
was the enviroment that I used.


### launch intrstruction
- activate Anaconda
- go to directory
- launch script is python launch.py
- there is a basic menu with result of experiments
